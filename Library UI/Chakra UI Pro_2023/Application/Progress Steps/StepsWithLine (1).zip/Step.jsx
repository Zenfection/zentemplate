import { Box } from '@chakra-ui/react'

export const Step = (props) => {
  const { isActive, ...boxProps } = props
  return (
    <Box
      flex="1"
      h="2"
      bg={isActive ? 'accent' : 'border.default'}
      borderRadius="base"
      transition="background 0.2s"
      {...boxProps}
    />
  )
}
