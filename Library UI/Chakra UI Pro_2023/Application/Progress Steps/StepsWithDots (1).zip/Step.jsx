import { Box } from '@chakra-ui/react'

export const Step = (props) => {
  const { isActive, ...boxProps } = props
  return (
    <Box
      boxSize="2.5"
      bg={isActive ? 'accent' : 'border.default'}
      borderRadius="full"
      transition="background 0.2s"
      {...boxProps}
    />
  )
}
