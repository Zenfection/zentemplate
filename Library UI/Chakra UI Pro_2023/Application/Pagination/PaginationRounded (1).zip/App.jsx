import { Box, Container } from '@chakra-ui/react'
import { useState } from 'react'
import { Pagination } from './Pagination'

export const App = () => {
  const [page, setPage] = useState(2)
  return (
    <Box bg="bg.surface">
      <Container
        py={{
          base: '12',
          md: '16',
        }}
      >
        <Pagination
          count={9}
          pageSize={1}
          siblingCount={2}
          page={page}
          onChange={(e) => setPage(e.page)}
        />
      </Container>
    </Box>
  )
}
