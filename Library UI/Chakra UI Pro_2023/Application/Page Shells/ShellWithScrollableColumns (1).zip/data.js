export const posts = [
  {
    id: '1',
    title: "For Heaven's Cakes!",
    excerpt: 'Marzipan lemon drops pastry brownie ice cream croissant sesame snaps candy danish.',
    publishedAt: 'November 8, 2021',
  },
  {
    id: '2',
    title: 'The shape of a cupcake',
    excerpt: 'Muffin cupcake sweet roll cake candy dragée jujubes toffee icing.',
    publishedAt: 'October 23, 2021',
  },
  {
    id: '3',
    title: 'Sweet Thang Cupcakes',
    excerpt: 'Lemon drops sesame snaps muffin lemon drops soufflé carrot cake.',
    publishedAt: 'November 12, 2021',
  },
  {
    id: '4',
    title: 'Cupcake Boulevard',
    excerpt: 'Bear claw jujubes chupa chups pie croissant liquorice muffin.',
    publishedAt: 'Juli 22, 2021',
  },
  {
    id: '5',
    title: 'Red Velvet Bakery',
    excerpt: ' Sesame snaps croissant powder dragée bonbon muffin tart dessert croissant.',
    publishedAt: 'June 1, 2021',
  },
  {
    id: '6',
    title: 'Cupcake Bakeoff',
    excerpt: ' Jelly gummies gummi bears powder muffin cookie gingerbread wafer.',
    publishedAt: 'February 4, 2021',
  },
  {
    id: '7',
    title: 'Sugar & Spice Cupcake Shop',
    excerpt: ' Toffee dessert sesame snaps oat cake powder jelly-o cake danish apple pie.',
    publishedAt: 'February 2, 2021',
  },
  {
    id: '8',
    title: 'My sweet dream',
    excerpt: ' Jelly gummies gummi bears powder muffin cookie gingerbread wafer.',
    publishedAt: 'January 18, 2021',
  },
]
