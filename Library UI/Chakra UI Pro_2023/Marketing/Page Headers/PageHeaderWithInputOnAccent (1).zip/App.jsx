import {
  Box,
  Container,
  Heading,
  Icon,
  Input,
  InputGroup,
  InputLeftElement,
  Stack,
  Text,
} from '@chakra-ui/react'
import { FiSearch } from 'react-icons/fi'

export const App = () => (
  <Box
    as="section"
    bg="bg.accent.default"
    color="fg.accent.default"
    py={{
      base: '16',
      md: '24',
    }}
  >
    <Container>
      <Stack
        spacing={{
          base: '8',
          md: '10',
        }}
        align="center"
      >
        <Stack
          spacing={{
            base: '4',
            md: '6',
          }}
          textAlign="center"
        >
          <Stack spacing="3">
            <Text
              fontSize={{
                base: 'sm',
                md: 'md',
              }}
              fontWeight="medium"
              color="blue.50"
            >
              Support
            </Text>
            <Heading
              size={{
                base: 'md',
                md: 'lg',
              }}
              fontWeight="semibold"
            >
              Welcome to Help Center
            </Heading>
          </Stack>
          <Text
            color="fg.accent.muted"
            fontSize={{
              base: 'lg',
              md: 'xl',
            }}
            maxW="3xl"
          >
            How can we help you?
          </Text>
        </Stack>
        <InputGroup
          size="xl"
          maxW={{
            md: 'sm',
          }}
        >
          <InputLeftElement pointerEvents="none">
            <Icon as={FiSearch} boxSize="5" color="fg.accent.default" />
          </InputLeftElement>
          <Input placeholder="Search" variant="filled.accent" />
        </InputGroup>
      </Stack>
    </Container>
  </Box>
)
