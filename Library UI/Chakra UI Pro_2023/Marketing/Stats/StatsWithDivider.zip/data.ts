export const stats = [
  {
    value: '210+',
    label: 'Components',
  },
  {
    value: '60%',
    label: 'Less development costs',
  },
  {
    value: '25k',
    label: 'GitHub stars',
  },
]
