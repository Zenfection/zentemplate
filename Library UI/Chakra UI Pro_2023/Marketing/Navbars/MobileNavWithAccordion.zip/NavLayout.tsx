import { Flex, HStack, Icon, IconButton, StackDivider } from '@chakra-ui/react'
import { RefObject } from 'react'
import { FiMenu, FiSun } from 'react-icons/fi'
import { MdClose } from 'react-icons/md'
import { Logo } from './Logo'

type NavLayoutProps = {
  onClickMenu?: VoidFunction
  onToggleMode?: VoidFunction
  isMenuOpen: boolean
  menuButtonRef?: RefObject<HTMLButtonElement>
}

export const NavLayout = (props: NavLayoutProps) => {
  const { onClickMenu, onToggleMode, isMenuOpen, menuButtonRef } = props
  const MenuIcon = isMenuOpen ? MdClose : FiMenu
  return (
    <Flex height="16" align="center" justify="space-between" px="5">
      <Logo />
      <HStack divider={<StackDivider height="6" alignSelf="unset" />}>
        <IconButton
          variant="tertiary"
          icon={<Icon as={FiSun} />}
          aria-label="Toggle color mode"
          onClick={onToggleMode}
        />
        <IconButton
          ref={menuButtonRef}
          variant="tertiary"
          icon={<Icon as={MenuIcon} />}
          aria-label="Open Menu"
          onClick={onClickMenu}
        />
      </HStack>
    </Flex>
  )
}
